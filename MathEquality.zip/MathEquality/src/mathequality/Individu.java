/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathequality;

import java.util.Random;

/**
 *
 * @author danang
 */
public class Individu {
    public int jml_gen;
    public double gen[] = new double[4];
    
    public Individu(int jml_gen){
        this.jml_gen=jml_gen;
        bangkitkan();
    }
    
    private void bangkitkan(){
        for (int i = 0; i < this.jml_gen; i++) {
            Random rand = new Random();
            this.gen[i] = rand.nextInt(31);
        }
    }
    
    public String get_individu(){
        String ind = "["+gen[0]+"]["+gen[1]+"]["+gen[2]+"]["+gen[3]+"]";
        return ind;
    }
    
    public double hitung_fitness() {
        double fitness;
        double sigma;
        sigma = (1*gen[0]) + (2*gen[1]) + (3*gen[2]) + (4*gen[3]);
        double minimasi = Math.abs(sigma-30);
        
        fitness = 1/(minimasi+1);
            
        //fitness -= sigma; //jika fitness diinginkan bernilai 0 s.d jml_gen*25 
        return fitness;
    }
}
