/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathequality;

/**
 *
 * @author danang
 */
public class MathEquality {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int jml_gen=4;
        int jml_individu=6;
        
        System.out.println("POPULASI AWAL");
        Individu populasi_awal[] = new Individu[jml_individu];
        for (int i = 0; i < jml_individu; i++) {
            populasi_awal[i] = new Individu(jml_gen);
            String indv = populasi_awal[i].get_individu();
            System.out.print("Individu ke : "+(i+1)+" = ");
            System.out.print(indv);
            System.out.println(" | fitness = "+ populasi_awal[i].hitung_fitness());
        }
    }
    
}
